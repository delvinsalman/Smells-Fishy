let data; // Variable to store the loaded CSV data
let boids = []; // Array to store boids (visual representations of data points)
let selectedCountry = null; // Currently selected country
let countryMenu; // Dropdown menu for selecting countries
let yearSlider; // Slider for selecting the year
let currentYear = 1961; // Current year selected by the slider
let particles = []; // Array to store particles for background animation
let bgParticles = []; // Array to store background particles
let hoveredBoid = null; // Boid currently hovered over by the mouse
let displayText = ""; // Text to display when hovering over a boid
let textAlpha = 0; // Alpha value for the hover text
let customFont; // Custom font for text rendering
let searchInput; // Input field for searching a specific year
let searchedYear = null; // Year searched by the user
let yearRangeText = ""; // Text to display the current year range
let bgNoise; // Background noise
let boidSounds = []; // Array to store sound effects for boids
let lastSoundPlayTime = 0; // Time when the last sound was played
let soundCooldown = 1000;
let seaDepth = 0; // Variable to control sea depth based on data
let seaTurbulence = 0; // Variable to control sea turbulence based on data
let seaColor; // Variable to control sea color based on data

// Preload function to load data and assets before setup
function preload() {
    data = loadTable('fish-and-seafood-consumption-per-capita.csv', 'csv', 'header');
    customFont = loadFont('Geoform-HeavyItalic.ttf');

    // Load background noise
    bgNoise = loadSound('Background.mp3');

    // Load sound effects for boids
    boidSounds.push(loadSound('Low.mp3'));
    boidSounds.push(loadSound('Mid.mp3'));
    boidSounds.push(loadSound('High.mp3'));
    // Add more sounds as needed
}

// Setup function to initialize the canvas and UI elements
function setup() {
    createCanvas(1890, 920); // Create a canvas with specified dimensions
    textFont(customFont); // Set the custom font for text rendering

    // Play background noise
    bgNoise.loop();
    bgNoise.setVolume(0.3);

    // Create a dropdown menu for selecting countries
    countryMenu = createSelect();
    let countries = [];
    for (let row of data.rows) {
        let entity = row.get('Entity');
        if (!countries.includes(entity)) {
            countries.push(entity);
        }
    }
    countries.forEach(country => countryMenu.option(country)); // Add each country to the dropdown
    countryMenu.changed(selectCountry); // Set the callback for when a country is selected

    // Create a button to select a random country
    randomCountryButton = createButton('Random Country');
    randomCountryButton.position(20, 140);
    randomCountryButton.mousePressed(randomCountry);

    // Create a slider for selecting the year
    let minYear = 1961;
    let maxYear = 2021;
    yearSlider = createSlider(minYear, maxYear, currentYear);
    yearSlider.position(20, height - 80); 
    yearSlider.style('width', '300px'); 
    yearSlider.changed(updateYear);

    // Create an input field for searching a specific year
    searchInput = createInput('');
    searchInput.position(20, 180);
    searchInput.input(searchYear);

    // Initialize the selected country and background particles
    selectCountry();
    for (let i = 0; i < 100; i++) {
        bgParticles.push(new BGParticle());
    }
    updateYearRangeText(); // Initialize the year range text
}

// Function to display the color legend
function displayColorLegend() {
    let legendX = 20;
    let legendY = 20;
    let legendWidth = 150;
    let legendHeight = 100;
    textSize(14);
    fill(255);
    textAlign(LEFT, TOP);
    text("Consumption Per Capita (kg)", legendX + 5, legendY + 5);
    let ranges = [0, 10, 20, 30, 40, 50];
    let legendStep = (legendHeight - 20) / (ranges.length - 1);

    for (let i = 0; i < ranges.length - 1; i++) {
        let yPos = legendY + 20 + i * legendStep;
        let colorValue = map(ranges[i], 0, 50, 0, 255);
        let legendColor = color(lerp(0, 255, colorValue / 255), 0, lerp(255, 0, colorValue / 255));
        fill(legendColor);
        rect(legendX + 5, yPos, 15, legendStep);
        fill(255);
        text(`${ranges[i]}-${ranges[i + 1]}`, legendX + 25, yPos + legendStep / 4);
    }

    // Position the country menu and other UI elements
    countryMenu.position(legendX, legendY + legendHeight + 10);
    randomCountryButton.position(legendX, legendY + legendHeight + countryMenu.height + 20);
    searchInput.position(legendX, randomCountryButton.y + randomCountryButton.height + 10);
}

// Function to search for a specific year
function searchYear() {
    let inputYear = parseInt(searchInput.value());
    if (!isNaN(inputYear)) {
        searchedYear = inputYear;
    } else {
        searchedYear = null;
    }
}

// Function to select a random country
function randomCountry() {
    let countries = [];
    for (let row of data.rows) {
        let entity = row.get('Entity');
        if (!countries.includes(entity)) {
            countries.push(entity);
        }
    }
    let randomIndex = floor(random(countries.length));
    let randomCountryName = countries[randomIndex];
    countryMenu.selected(randomCountryName);
    selectCountry();
}

// Main draw function
function draw() {
    drawBackground(); // Draw the background
    updateParticles(); // Update and display particles
    displayParticles();

    if (selectedCountry) {
        let countryBoids = boids.filter(b => b.entity === selectedCountry && parseInt(b.year) <= currentYear);
        for (let boid of countryBoids) {
            if (hoveredBoid !== boid) {
                boid.update();
            }
            boid.display();
        }

        // Highlight the boid for the searched year if it exists
        if (searchedYear !== null) {
            let searchedBoid = boids.find(b => b.entity === selectedCountry && parseInt(b.year) === searchedYear);
            if (searchedBoid) {
                searchedBoid.displayGlow();
                searchedBoid.displayWhiteGlow(); // Add white glow ring
            }
        }
    }

    // Display various UI elements
    displayTitleAndYear();
    displayHoverText();
    displayAverageConsumption();
    displayColorLegend();
    displayYearSliderInfo(); // Display year slider information
}

// Function to display the title and current year range
function displayTitleAndYear() {
    fill(255);
    textSize(30);
    textAlign(CENTER, TOP);
    text("Seafood Consumption Data Visualization", width / 2, 10);
    textSize(20);
    text(`${yearRangeText}`, width / 2, 40); // Display the year range text
}

// Function to update the current year based on the slider
function updateYear() {
    currentYear = yearSlider.value();
    updateBoids();
    updateYearRangeText(); // Update the year range text when the slider changes
}

// Function to update the year range text
function updateYearRangeText() {
    yearRangeText = `Year: 1961-${currentYear}`;
}

// Function to display the year slider information
function displayYearSliderInfo() {
    fill(255);
    textSize(16);
    textAlign(CENTER, TOP);
    text(`Selected Year: ${currentYear}`, yearSlider.x + yearSlider.width / 2, yearSlider.y + yearSlider.height + 10);
    text(`Min: 1961 | Max: 2021`, yearSlider.x + yearSlider.width / 2, yearSlider.y + yearSlider.height + 30);
}

function selectCountry() {
    selectedCountry = countryMenu.value();
    boids = [];
    updateBoids();
    updateSeaEnvironment();
}

// Function to update the boids based on the selected country and year
function updateBoids() {
    boids = boids.filter(b => b.entity !== selectedCountry);
    for (let row of data.rows) {
        let entity = row.get('Entity');
        let year = row.get('Year');
        let consumption = row.get('Fish and seafood | 00002960 || Food available for consumption | 0645pc || kilograms per year per capita');
        if (entity === selectedCountry) {
            let boid = new Boid(entity, year, consumption);
            boids.push(boid);
        }
    }
}

// Function to draw the background
function drawBackground() {
    background(seaColor); // Set the base background color

    // Draw underwater effects
    drawUnderwaterWaves();
    drawUnderwaterParticles();
    drawUnderwaterDepth();

    // Update and display background particles
    for (let particle of bgParticles) {
        particle.update();
        particle.display();
    }
}

// Function to draw underwater waves
function drawUnderwaterWaves() {
    noFill();
    stroke(255, 30);
    strokeWeight(1);
    let waveHeight = 10 + seaTurbulence * 5;
    let waveSpeed = 0.01 + seaTurbulence * 0.01;
    for (let y = 0; y < height; y += 20) {
        beginShape();
        for (let x = 0; x < width; x += 5) {
            let angle = x * 0.01 + frameCount * waveSpeed;
            let offset = map(sin(angle), -1, 1, -waveHeight, waveHeight);
            curveVertex(x, y + offset);
        }
        endShape();
    }
}

// Function to draw underwater particles (bubbles, etc.)
function drawUnderwaterParticles() {
    for (let i = 0; i < seaDepth * 2; i++) {
        let x = random(width);
        let y = random(height);
        let size = random(2, 6);
        let alpha = random(50, 150);
        fill(200, 220, 255, alpha);
        noStroke();
        ellipse(x, y, size, size);
    }
}

// Function to draw underwater depth effect
function drawUnderwaterDepth() {
    let depthGradient = createLinearGradient(0, 0, 0, height, seaColor, color(0, 0, seaDepth * 5));
    drawingContext.fillStyle = depthGradient;
    rect(0, 0, width, height);
}

// Function to create linear gradient
function createLinearGradient(x1, y1, x2, y2, color1, color2) {
    let gradient = drawingContext.createLinearGradient(x1, y1, x2, y2);
    gradient.addColorStop(0, color1);
    gradient.addColorStop(1, color2);
    return gradient;
}

// Function to update sea environment based on average consumption
function updateSeaEnvironment() {
    let totalConsumption = 0;
    let count = 0;
    for (let row of data.rows) {
        if (row.get('Entity') === selectedCountry) {
            totalConsumption += parseFloat(row.get('Fish and seafood | 00002960 || Food available for consumption | 0645pc || kilograms per year per capita'));
            count++;
        }
    }
    if (count > 0) {
        let average = totalConsumption / count;
        seaDepth = map(average, 0, 50, 5, 20); // Adjust range as needed
        seaTurbulence = map(average, 0, 50, 0.1, 1);
        seaColor = lerpColor(color(10, 50, 100), color(0, 80, 150), average / 50);
    } else {
        seaDepth = 5;
        seaTurbulence = 0.1;
        seaColor = color(10, 50, 100);
    }
}

// Function to update particles
function updateParticles() {
    if (frameCount % 2 === 0) {
        particles.push(new Particle());
    }
    for (let i = particles.length - 1; i >= 0; i--) {
        particles[i].update();
        if (particles[i].isDead()) {
            particles.splice(i, 1);
        }
    }
}

// Function to display particles
function displayParticles() {
    for (let particle of particles) {
        particle.display();
    }
}

// Function to display hover text
function displayHoverText() {
    if (textAlpha > 0) {
        fill(255, textAlpha);
        textSize(18);
        textAlign(CENTER, CENTER);
        text(displayText, width / 2, height - 50);
        textAlpha -= 2;
    }
}

// Function to display the average consumption for the selected country
function displayAverageConsumption() {
    let totalConsumption = 0;
    let count = 0;
    for (let row of data.rows) {
        if (row.get('Entity') === selectedCountry) {
            totalConsumption += parseFloat(row.get('Fish and seafood | 00002960 || Food available for consumption | 0645pc || kilograms per year per capita'));
            count++;
        }
    }
    if (count > 0) {
        let average = totalConsumption / count;
        fill(255);
        textSize(20);
        textAlign(RIGHT, TOP);
        text(`${selectedCountry}: ${average.toFixed(2)} kg/year (Per Capita)`, width - 20, 10);
    }
}

// Class for background particles
class BGParticle {
    constructor() {
        this.position = createVector(random(width), random(height));
        this.velocity = createVector(random(-0.3, 0.3), random(0.1, 0.5));
        this.size = random(1, 4);
        this.alpha = random(30, 80);
        this.color = random([color(200, 220, 255, this.alpha), color(150, 180, 220, this.alpha)]);
        this.noiseOffset = createVector(random(100), random(100));
        this.noiseScale = 0.01;
    }

    update() {
        let noiseX = noise(this.noiseOffset.x + frameCount * this.noiseScale);
        let noiseY = noise(this.noiseOffset.y + frameCount * this.noiseScale);
        this.velocity.x = map(noiseX, 0, 1, -0.5, 0.5);
        this.velocity.y = map(noiseY, 0, 1, 0.1, 0.5);

        this.position.add(this.velocity);
        if (this.position.x < 0) this.position.x = width;
        if (this.position.x > width) this.position.x = 0;
        if (this.position.y < 0) this.position.y = height;
        if (this.position.y > height) this.position.y = 0;
    }

    display() {
        noStroke();
        fill(this.color);
        ellipse(this.position.x, this.position.y, this.size, this.size);
    }
}

// Class for particles
class Particle {
    constructor() {
        this.position = createVector(random(width), random(height));
        this.velocity = p5.Vector.random2D();
        this.velocity.mult(random(0.3, 1));
        this.lifespan = random(150, 255);
        this.size = random(1, 3);
        this.color = random([color(200, 220, 255, this.lifespan), color(150, 180, 220, this.lifespan)]);
        this.noiseOffset = createVector(random(100), random(100));
        this.noiseScale = 0.02;
    }

    update() {
        let noiseX = noise(this.noiseOffset.x + frameCount * this.noiseScale);
        let noiseY = noise(this.noiseOffset.y + frameCount * this.noiseScale);
        this.velocity.x = map(noiseX, 0, 1, -0.3, 0.3);
        this.velocity.y = map(noiseY, 0, 1, -0.3, 0.3);

        this.position.add(this.velocity);
        this.lifespan -= 1.5;
    }

    display() {
        noStroke();
        fill(this.color);
        ellipse(this.position.x, this.position.y, this.size, this.size);
    }

    isDead() {
        return this.lifespan < 0;
    }
}

// Class for boids (data points)
class Boid {
    constructor(entity, year, consumption) {
        this.entity = entity;
        this.year = year;
        this.consumption = parseFloat(consumption);

        this.position = createVector(random(width), random(height));
        this.velocity = p5.Vector.random2D();
        this.velocity.setMag(this.getSpeedFromConsumption(this.consumption));
        this.acceleration = createVector();
        this.size = map(this.consumption, 0, 50, 20, 40);
        this.color = this.getColorFromConsumption(this.consumption);
        this.trail = [];
        this.hoverSize = this.size * 1.2;
        this.eyeAngle = random(TWO_PI);
        this.eyeMoveSpeed = random(0.01, 0.05);
        this.bubbleTrail = [];

        // Assign a sound effect based on color
        this.sound = this.getSoundFromColor(this.color);
    }

    getSpeedFromConsumption(consumption) {
        return map(consumption, 0, 50, 0.5, 3);
    }

    getColorFromConsumption(consumption) {
        let colorValue = map(consumption, 0, 50, 0, 255);
        return color(lerp(0, 255, colorValue / 255), 0, lerp(255, 0, colorValue / 255));
    }

    getSoundFromColor(color) {
        let colorValue = red(color);
        let soundIndex = floor(map(colorValue, 0, 255, 0, boidSounds.length - 1));
        return boidSounds[soundIndex];
    }

    cohesion(boids) {
        let perceptionRadius = 100;
        let steering = createVector(0, 0);
        let total = 0;
        let avgPosition = createVector(0, 0);

        for (let other of boids) {
            let d = dist(this.position.x, this.position.y, other.position.x, other.position.y);
            if (d < perceptionRadius && other !== this) {
                avgPosition.add(other.position);
                total++;
            }
        }

        if (total > 0) {
            avgPosition.div(total);
            steering = p5.Vector.sub(avgPosition, this.position);
            steering.setMag(0.05);
        }
        return steering;
    }

    align(boids) {
        let perceptionRadius = 100;
        let steering = createVector(0, 0);
        let total = 0;
        let avgVelocity = createVector(0, 0);

        for (let other of boids) {
            let d = dist(this.position.x, this.position.y, other.position.x, other.position.y);
            if (d < perceptionRadius && other !== this) {
                avgVelocity.add(other.velocity);
                total++;
            }
        }

        if (total > 0) {
            avgVelocity.div(total);
            avgVelocity.setMag(1.5);
            steering = p5.Vector.sub(avgVelocity, this.velocity);
            steering.limit(0.05);
        }
        return steering;
    }

    separate(boids) {
        let desiredSeparation = 40;
        let steering = createVector(0, 0);
        let total = 0;

        for (let other of boids) {
            let d = dist(this.position.x, this.position.y, other.position.x, other.position.y);
            if (d < desiredSeparation && other !== this) {
                let diff = p5.Vector.sub(this.position, other.position);
                diff.div(d);
                steering.add(diff);
                total++;
            }
        }

        if (total > 0) {
            steering.div(total);
        }

        if (steering.mag() > 0) {
            steering.setMag(1.5);
        }
        return steering;
    }

    flock(boids) {
        let alignment = this.align(boids);
        let cohesion = this.cohesion(boids);
        let separation = this.separate(boids);

        alignment.mult(1.0);
        cohesion.mult(1.0);
        separation.mult(1.5);

        this.acceleration.add(alignment);
        this.acceleration.add(cohesion);
        this.acceleration.add(separation);
    }

    update() {
        let countryBoids = boids.filter(b => b.entity === this.entity && parseInt(b.year) <= currentYear);
        this.flock(countryBoids);

        if (this.position.x < 0) this.position.x = width;
        if (this.position.x > width) this.position.x = 0;
        if (this.position.y < 0) this.position.y = height;
        if (this.position.y > height) this.position.y = 0;

        this.position.add(this.velocity);
        this.velocity.add(this.acceleration);
        this.velocity.limit(this.getSpeedFromConsumption(this.consumption));
        this.acceleration.mult(0);

        this.trail.push({ position: this.position.copy(), alpha: 255 });
        if (this.trail.length > 20) {
            this.trail.shift();
        }

        for (let i = 0; i < this.trail.length; i++) {
            this.trail[i].alpha -= 10;
        }

        this.eyeAngle += random(-this.eyeMoveSpeed, this.eyeMoveSpeed);

        // Add bubble trail logic
        if (frameCount % 5 === 0) {
            this.bubbleTrail.push({
                position: this.position.copy(),
                size: random(3, 8),
                alpha: 255
            });
        }

        for (let i = this.bubbleTrail.length - 1; i >= 0; i--) {
            this.bubbleTrail[i].alpha -= 5;
            this.bubbleTrail[i].size *= 0.95;
            if (this.bubbleTrail[i].alpha <= 0) {
                this.bubbleTrail.splice(i, 1);
            }
        }
    }

    display() {
        // Display bubble trail
        for (let bubble of this.bubbleTrail) {
            fill(200, 220, 255, bubble.alpha);
            noStroke();
            ellipse(bubble.position.x, bubble.position.y, bubble.size, bubble.size);
        }

        for (let i = 0; i < this.trail.length; i++) {
            let trailAlpha = this.trail[i].alpha;
            let trailSize = map(i, 0, this.trail.length, this.size * 0.5, this.size * 0.1);
            fill(this.color, trailAlpha);
            noStroke();
            ellipse(this.trail[i].position.x, this.trail[i].position.y, trailSize, trailSize);
        }

        let displaySize = this.size;
        if (this.isMouseOver()) {
            displaySize = this.hoverSize;
            this.displayGlow();
            hoveredBoid = this;
            displayText = `Year: ${this.year} | Consumption: ${this.consumption.toFixed(2)} kg`;
            textAlpha = 255;

            // Play sound effect on hover with cooldown
            let currentTime = millis();
            if (currentTime - lastSoundPlayTime > soundCooldown) {
                if (!this.sound.isPlaying()) {
                    this.sound.play();
                    lastSoundPlayTime = currentTime;
                }
            }
        } else if (hoveredBoid === this && !this.isMouseOver()) {
            hoveredBoid = null;
        }

        fill(this.color);
        noStroke();
        ellipse(this.position.x, this.position.y, displaySize, displaySize);
        for (let i = 0; i < 3; i++) {
            fill(this.color, 100 - i * 30);
            ellipse(this.position.x, this.position.y, displaySize * (1 + i * 0.2), displaySize * (1 + i * 0.2));
        }
        this.displayEyes();
    }

    displayEyes() {
        let eyeSize = this.size * 0.2;
        let eyeOffsetX = cos(this.eyeAngle) * this.size * 0.3;
        let eyeOffsetY = sin(this.eyeAngle) * this.size * 0.1;

        fill(255);
        ellipse(this.position.x + eyeOffsetX, this.position.y - this.size / 2 + eyeOffsetY, eyeSize, eyeSize);
        ellipse(this.position.x - eyeOffsetX, this.position.y - this.size / 2 + eyeOffsetY, eyeSize, eyeSize);
        fill(0);
        ellipse(this.position.x + eyeOffsetX, this.position.y - this.size / 2 + eyeOffsetY, eyeSize * 0.5, eyeSize * 0.5);
        ellipse(this.position.x - eyeOffsetX, this.position.y - this.size / 2 + eyeOffsetY, eyeSize * 0.5, eyeSize * 0.5);
    }

    displayGlow() {
        let glowSize = this.size * 2;
        let glowAlpha = 100;
        for (let i = 0; i < 3; i++) {
            fill(this.color, glowAlpha);
            noStroke();
            ellipse(this.position.x, this.position.y, glowSize, glowSize);
            glowSize *= 0.8;
            glowAlpha *= 0.7;
        }
    }

    displayWhiteGlow() {
        let glowSize = this.size * 2.5;
        let glowAlpha = 100;
        for (let i = 0; i < 3; i++) {
            fill(255, glowAlpha);
            noStroke();
            ellipse(this.position.x, this.position.y, glowSize, glowSize);
            glowSize *= 0.8;
            glowAlpha *= 0.7;
        }
    }

    isMouseOver() {
        return dist(mouseX, mouseY, this.position.x, this.position.y) < this.size / 2;
    }
}

// Function to toggle background noise mute
function keyPressed() {
    if (key === 'm' || key === 'M') {
        if (bgNoise.isPlaying()) {
            bgNoise.stop();
        } else {
            bgNoise.play();
        }
    }
}